export const PegaErrors = {
  VALIDATION_ERROR: "Pega_API_055",
  NOT_AUTHORIZED: "Pega_API_XXX" // placeholder
};
